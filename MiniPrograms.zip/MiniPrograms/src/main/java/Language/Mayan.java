/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Language;

/**
 *
 * @author viktoriiatkachenko
 */
class Mayan extends Language {

  Mayan (String name, int numSpeakers) {
    super(name, numSpeakers, "Central America","verb-object-subject");
  }
    @Override
    public void getInfo() {
      System.out.println(this.name + " is spoken by " + this.numSpeakers + " people mainly in " + this.regionSpoken + ".");
    System.out.println("The language follows the word order: " + this.wordOrder);
    System.out.println("Fun fact: " + this.name + " is an ergative language.");
    }
  }

