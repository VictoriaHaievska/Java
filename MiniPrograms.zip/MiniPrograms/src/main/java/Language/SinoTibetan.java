/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Language;

/**
 *
 * @author viktoriiatkachenko
 */
public class SinoTibetan extends Language {

SinoTibetan (String name, int numSpeakers) {
  super (name, numSpeakers, "Asia", "subject-object-verb");

  if (name.contains("Chinese")) {
    this.wordOrder = "subject-verb-object";
  }
}

}
