/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Language;

/**
 *
 * @author viktoriiatkachenko
 */
class Language {
  protected String name;
  protected int numSpeakers;
  protected String regionSpoken;
  protected String wordOrder;

public Language (String name, int numSpeakers, String regionSpoken, String wordOrder) {
  this.name = name;
  this.numSpeakers = numSpeakers;
  this.regionSpoken = regionSpoken;
  this.wordOrder = wordOrder;

}

public void getInfo(){
  System.out.println(this.name + " is spoken by " +   this.numSpeakers + " people mainly in " + this.regionSpoken + ".");
    System.out.println("The language follows the word order: " + this.wordOrder);
}

public static void main (String[] args){
Language newLang = new Language("japanese", 17000000, "Japan", "subject-object-verb order");
newLang.getInfo();

Mayan newMayan = new Mayan ("Huastek", 161120);
newMayan.getInfo();

SinoTibetan newTibetian1 = new SinoTibetan("Chinese Mandarin", 500000000);
SinoTibetan newTibetian2 = new SinoTibetan ("Burmese", 16000000);

newTibetian1.getInfo();
newTibetian2.getInfo();

  }
}