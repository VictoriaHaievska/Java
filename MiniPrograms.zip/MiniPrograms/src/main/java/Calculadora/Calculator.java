package Calculadora;


/** This program accepts two integers as parameters and immitates a calcucator*/

public class Calculator {

//constructor class
public Calculator(){

}

  public int add(int a, int b) {
    int sum = a+b;
    return sum;
  }
  public int substract(int a, int b) {
    int substract = a-b;
    return substract;
  }
  public int multiply(int a, int b) {
    int multiply = a*b;
    return multiply;
  }
  public int divide(int a, int b) {
    int divide = a/b;
    return divide;
  }

  public int modulo(int a, int b) {
    int modulo = a%b;
    return modulo;
  }

public static void main(String[] args){
  Calculator myCalculator = new Calculator();
  System.out.println(myCalculator.add(5, 7));
  System.out.println(myCalculator.substract(45, 11));
  System.out.println(myCalculator.modulo(11, 4));
 } 
}